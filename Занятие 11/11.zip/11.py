import requests
from tkinter import *


def click():
    print('Введите owner')
    owner = txt1.get()
    print('Введите repo')
    repo = txt2.get()
    r = requests.get(f'https://api.github.com/repos/{owner}/{repo}')

    with open('C:\\Users\\My\\PycharmProjects\\pythonProject\\Основы\\lesson 11\\4123', 'w') as f:
        if 'company' in r.json():
            f.write(f"'company': '{r.json()['company']}'\n")
        else:
            f.write("'company':")
            f.write('None\n')
        f.write(f"'created_at': '{r.json()['created_at']}'\n")
        if 'email' in r.json():
            f.write(f"'email': '{r.json()['email']}'\n")
        else:
            f.write("'email':")
            f.write('None\n')
        f.write(f"'id': '{r.json()['id']}'\n")
        f.write(f"'name': '{r.json()['name']}'\n")
        f.write(f"'url': '{r.json()['url']}'\n")
        print('См. результат в файле')


window = Tk()
window.title('Магутина')
window.geometry('600x300')
window.resizable(False, False)
lbl = Label(window, text='Напишите сначала owner, затем repo', font=('Times New Roman', 20))
lbl.grid(column=0, row=0)
btn = Button(window, text='Клик', command=click)
btn.grid(column=2, row=0)
txt1 = Entry(window, width=10)
txt1.grid(column=1, row=0)
txt2 = Entry(window, width=10)
txt2.grid(column=1, row=2)
window.mainloop()
